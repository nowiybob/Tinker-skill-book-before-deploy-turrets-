package com.example.skillbook;

import com.mojang.serialization.Codec;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.creativetab.v1.FabricCreativeModeTab;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Registry;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSystemChatPacket;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;

import java.util.*;
import java.util.function.Function;

public class SkillBookMod implements ModInitializer {
    public static final String MODID = "skillbook";

    // ---- Способности: 0 Лазер, 1 Марши, 2 Матрица, 3 Варп-флейр, 4 Реарм, 5 ТП ----
    static final String[] IDS = {"laser", "marches", "matrix", "warp", "rearm", "tp", "aegis"};
    static final String[] NAMES = {"Лазер", "Марши", "Матрица", "Варп-флейр", "Реарм", "ТП", "Эгида"};
    static final int[] SLOT_OF = {0, 1, 2, 3, 4, 8, 5};              // слоты хотбара (1-5 и 9)
    static final int[] CD = {15 * 20, 20 * 20, 10 * 20, 15 * 20, 0, 50 * 20, 0}; // КД в тиках
    static final int REARM_TICKS = 30;         // 1.5 сек
    static final int TP_TICKS = 40;            // 2 сек
    static final int INTERRUPT_CD = 5 * 20;    // КД если сбили Реарм/ТП
    static final int BLIND_TICKS = 4 * 20;     // длительность "ослепления" после лазера
    static final int MARCH_LIFETIME = 7 * 20;  // роботы живут 7 сек

    static final int[] STORED = new int[37];   // слоты, которые прячем (кроме брони): 0..35 и оффхенд 40
    static { for (int i = 0; i < 36; i++) STORED[i] = i; STORED[36] = 40; }

    static Item BOOK;
    /** Все книги персонажей. Новая книга, добавленная через characterBook(), сама попадёт во вкладку Dota2 Characters. */
    static final List<Item> CHARACTER_BOOKS = new ArrayList<>();
    static Item AEGIS; // предмет, который лежит в логове Рошана
    static final int AEGIS_IDX = 6;
    static final int REVIVE_TICKS = 60; // 3 секунды
    static final List<Item> SKILLS = new ArrayList<>();

    // Данные игрока (сохраняются). UNLOCKED остаётся после смерти.
    static final AttachmentType<Boolean> UNLOCKED = AttachmentRegistry.create(
            Identifier.fromNamespaceAndPath(MODID, "unlocked"),
            b -> b.initializer(() -> false).persistent(Codec.BOOL).copyOnDeath());
    static final AttachmentType<Boolean> MODE = AttachmentRegistry.create(
            Identifier.fromNamespaceAndPath(MODID, "mode"),
            b -> b.initializer(() -> false).persistent(Codec.BOOL));
    static final AttachmentType<List<ItemStack>> SAVED = AttachmentRegistry.create(
            Identifier.fromNamespaceAndPath(MODID, "saved"),
            b -> b.initializer(() -> List.<ItemStack>of()).persistent(ItemStack.OPTIONAL_CODEC.listOf()));

    static final AttachmentType<Boolean> HAS_AEGIS = AttachmentRegistry.create(
            Identifier.fromNamespaceAndPath(MODID, "has_aegis"),
            b -> b.initializer(() -> false).persistent(Codec.BOOL));

    // Временные состояния (не сохраняются)
    record Channel(int type, long end) {}                       // type 4 = Реарм, 5 = ТП
    record Blind(UUID owner, long end) {}
    record Robot(ArmorStand stand, UUID owner, Vec3 start, Vec3 fwd, long born) {}
    static final Map<UUID, Channel> CHANNELS = new HashMap<>();
    static final Map<UUID, Long> DOME = new HashMap<>();
    static final Map<UUID, Long> REVIVE = new HashMap<>();
    static final Map<UUID, Blind> BLIND = new HashMap<>();
    static final List<Robot> ROBOTS = new ArrayList<>();

    static Item register(Identifier id, Function<Item.Properties, Item> f) {
        Item.Properties p = new Item.Properties().stacksTo(1).setId(ResourceKey.create(Registries.ITEM, id));
        return Registry.register(BuiltInRegistries.ITEM, id, f.apply(p));
    }

    static Item characterBook(Identifier id, Function<Item.Properties, Item> f) {
        Item it = register(id, f);
        CHARACTER_BOOKS.add(it);
        return it;
    }

    @Override
    public void onInitialize() {
        // /give @s minecraft:tinker_book  (зарегистрирован в пространстве minecraft)
        BOOK = characterBook(Identifier.withDefaultNamespace("tinker_book"), TinkerBook::new);
        AEGIS = register(Identifier.fromNamespaceAndPath(MODID, "aegis"), Item::new);
        for (int i = 0; i < IDS.length; i++) {
            final int idx = i;
            SKILLS.add(register(Identifier.fromNamespaceAndPath(MODID, "skill_" + IDS[i]), p -> new SkillItem(p, idx)));
        }

        // Вкладка творческого режима "Dota2 Characters"
        ResourceKey<CreativeModeTab> tabKey = ResourceKey.create(BuiltInRegistries.CREATIVE_MODE_TAB.key(),
                Identifier.fromNamespaceAndPath(MODID, "characters"));
        CreativeModeTab tab = FabricCreativeModeTab.builder()
                .icon(() -> new ItemStack(BOOK))
                .title(Component.translatable("creativeTab.skillbook.characters"))
                .displayItems((params, output) -> {
                    for (Item book : CHARACTER_BOOKS) output.accept(book);
                })
                .build();
        Registry.register(BuiltInRegistries.CREATIVE_MODE_TAB, tabKey, tab);

        CommandRegistrationCallback.EVENT.register((dispatcher, ctx, env) -> {
            dispatcher.register(Commands.literal("skillmode").executes(c -> {
                toggle(c.getSource().getPlayerOrException());
                return 1;
            }));
            dispatcher.register(Commands.literal("dotamap")
                    .executes(c -> {
                        ServerPlayer p = c.getSource().getPlayerOrException();
                        if (DotaMap.current != null) {
                            msg(p, "Карта уже строится. /dotamap stop - отменить", false);
                            return 0;
                        }
                        DotaMap.current = new DotaMap((ServerLevel) p.level(), p.getUUID(),
                                p.getBlockX(), p.getBlockY() - 1, p.getBlockZ());
                        msg(p, "Строю карту 500x500 вокруг тебя (около минуты). Стой на месте.", false);
                        return 1;
                    })
                    .then(Commands.literal("stop").executes(c -> {
                        if (DotaMap.current != null) DotaMap.current.cancelled = true;
                        return 1;
                    })));
        });

        ServerTickEvents.END_SERVER_TICK.register(this::serverTick);

        // Купол и "ослепление" лазером
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {
            long now = entity.level().getGameTime();
            if (entity instanceof ServerPlayer && REVIVE.containsKey(entity.getUUID())) return false;
            Long dome = DOME.get(entity.getUUID());
            if (entity instanceof ServerPlayer && dome != null && dome > now) return false;
            var attacker = source.getEntity();
            if (attacker != null && source.getDirectEntity() == attacker) { // физический (ближний) урон
                Blind b = BLIND.get(attacker.getUUID());
                if (b != null && b.end() > now && b.owner().equals(entity.getUUID())) return false;
            }
            return true;
        });

        // Любой полученный урон сбивает Реарм / ТП
        ServerLivingEntityEvents.AFTER_DAMAGE.register((entity, source, base, taken, blocked) -> {
            if (entity instanceof ServerPlayer p && taken > 0) {
                Channel ch = CHANNELS.remove(p.getUUID());
                if (ch != null) {
                    p.getCooldowns().addCooldown(new ItemStack(SKILLS.get(ch.type())), INTERRUPT_CD);
                    msg(p, NAMES[ch.type()] + " сбит! КД 5 c", true);
                }
            }
        });

        // Перед смертью возвращаем инвентарь, чтобы дропнулись настоящие вещи, а не скиллы
        ServerLivingEntityEvents.ALLOW_DEATH.register((entity, source, amount) -> {
            if (entity instanceof ServerPlayer p) {
                // Эгида: смерть отменяется, через 3 секунды воскрешение на том же месте с теми же вещами
                if (p.getAttachedOrElse(HAS_AEGIS, false) && !REVIVE.containsKey(p.getUUID())) {
                    p.setAttached(HAS_AEGIS, false);
                    p.removeAllEffects();
                    p.clearFire();
                    p.setHealth(1f);
                    CHANNELS.remove(p.getUUID());
                    DOME.remove(p.getUUID());
                    REVIVE.put(p.getUUID(), p.level().getGameTime() + REVIVE_TICKS);
                    msg(p, "Эгида: воскрешение через 3 c", true);
                    return false;
                }
                if (p.getAttachedOrElse(MODE, false)) exitMode(p);
            }
            return true;
        });

        // Выброшенные предметы-скиллы удаляем
        ServerEntityEvents.ENTITY_LOAD.register((entity, world) -> {
            if (entity instanceof ItemEntity ie && isSkill(ie.getItem())) ie.discard();
        });
    }

    /** Сообщение игроку: overlay=true - над хотбаром, false - в чат. */
    static void msg(ServerPlayer p, String text, boolean overlay) {
        p.connection.send(new ClientboundSystemChatPacket(Component.literal(text), overlay));
    }

    /** setSmall закрыт (private) в этой версии, поэтому вызываем через рефлексию. */
    static void makeSmall(ArmorStand st) {
        try {
            var m = ArmorStand.class.getDeclaredMethod("setSmall", boolean.class);
            m.setAccessible(true);
            m.invoke(st, true);
        } catch (Exception ignored) { }
    }

    /** Подобрал предмет Эгиды (из логова) - он превращается в воскрешение. */
    static void scanAegis(ServerPlayer p) {
        if (p.getAttachedOrElse(HAS_AEGIS, false)) return;
        Inventory inv = p.getInventory();
        for (int i = 0; i < inv.getContainerSize(); i++) {
            if (inv.getItem(i).is(AEGIS)) {
                inv.setItem(i, ItemStack.EMPTY);
                p.setAttached(HAS_AEGIS, true);
                msg(p, "Ты подобрал Эгиду! После смерти воскреснешь через 3 c на том же месте.", false);
                return;
            }
        }
    }

    static void tickRevive(ServerPlayer p, ServerLevel sl, long now) {
        Long end = REVIVE.get(p.getUUID());
        if (end == null) return;
        if (now >= end) {
            REVIVE.remove(p.getUUID());
            p.setHealth(p.getMaxHealth());
            p.removeEffect(MobEffects.SLOWNESS);
            p.removeEffect(MobEffects.BLINDNESS);
            sl.playSound(null, p.blockPosition(), SoundEvents.PLAYER_LEVELUP, SoundSource.PLAYERS, 1f, 0.8f);
            sl.sendParticles(ParticleTypes.TOTEM_OF_UNDYING, p.getX(), p.getY() + 1, p.getZ(), 60, 0.5, 1, 0.5, 0.4);
            msg(p, "Эгида: ты воскрес!", true);
            return;
        }
        p.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, 5, 255, false, false));
        p.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 30, 0, false, false));
        sl.sendParticles(ParticleTypes.TOTEM_OF_UNDYING, p.getX(), p.getY() + 0.5, p.getZ(), 4, 0.4, 0.8, 0.4, 0.1);
        if ((end - now) % 20 == 0) msg(p, "Эгида: воскрешение через " + ((end - now) / 20) + " c", true);
    }

    static boolean isSkill(ItemStack s) { return SKILLS.contains(s.getItem()); }

    static int skillIndexOfSlot(int slot) {
        for (int i = 0; i < SLOT_OF.length; i++) if (SLOT_OF[i] == slot) return i;
        return -1;
    }

    // ---------------- Предметы ----------------
    static class TinkerBook extends Item {
        TinkerBook(Properties p) { super(p); }

        @Override
        public InteractionResult use(Level level, Player player, InteractionHand hand) {
            if (level instanceof ServerLevel && player instanceof ServerPlayer sp) {
                if (sp.getAttachedOrElse(UNLOCKED, false)) {
                    msg(sp, "Способности уже изучены. Нажми G.", true);
                } else {
                    sp.setAttached(UNLOCKED, true);
                    player.getItemInHand(hand).shrink(1); // книга пропадает
                    msg(sp, "Способности изучены навсегда! Нажми G.", false);
                    ((ServerLevel) level).playSound(null, sp.blockPosition(), SoundEvents.PLAYER_LEVELUP, SoundSource.PLAYERS, 1f, 1f);
                }
            }
            return InteractionResult.SUCCESS;
        }
    }

    static class SkillItem extends Item {
        final int idx;
        SkillItem(Properties p, int idx) { super(p); this.idx = idx; }

        @Override
        public InteractionResult use(Level level, Player player, InteractionHand hand) {
            if (level instanceof ServerLevel && player instanceof ServerPlayer sp) cast(sp, idx);
            return InteractionResult.SUCCESS;
        }
    }

    // ---------------- Режим способностей (G) ----------------
    static void toggle(ServerPlayer p) {
        if (!p.getAttachedOrElse(UNLOCKED, false)) {
            msg(p, "Сначала используй Tinker guide book", true);
            return;
        }
        if (p.getAttachedOrElse(MODE, false)) exitMode(p); else enterMode(p);
    }

    static void enterMode(ServerPlayer p) {
        Inventory inv = p.getInventory();
        List<ItemStack> saved = new ArrayList<>();
        for (int s : STORED) {
            saved.add(inv.getItem(s).copy());
            inv.setItem(s, ItemStack.EMPTY);
        }
        p.setAttached(SAVED, saved);
        p.setAttached(MODE, true);
        boolean aegis = p.getAttachedOrElse(HAS_AEGIS, false);
        for (int i = 0; i < SKILLS.size(); i++) {
            if (i == AEGIS_IDX && !aegis) continue;
            inv.setItem(SLOT_OF[i], new ItemStack(SKILLS.get(i)));
        }
        msg(p, "Режим способностей: ВКЛ", true);
    }

    static void exitMode(ServerPlayer p) {
        enforce(p); // спрятать то, что подобрали в этом же тике, чтобы ничего не потерялось
        Inventory inv = p.getInventory();
        List<ItemStack> saved = p.getAttachedOrElse(SAVED, List.of());
        for (int k = 0; k < STORED.length; k++) {
            inv.setItem(STORED[k], k < saved.size() ? saved.get(k).copy() : ItemStack.EMPTY);
        }
        p.setAttached(SAVED, List.of());
        p.setAttached(MODE, false);
        CHANNELS.remove(p.getUUID());
        msg(p, "Режим способностей: ВЫКЛ", true);
    }

    /** Следим, чтобы в режиме способностей в слотах были только скиллы. Подобранное прячется в хранилище. */
    static void enforce(ServerPlayer p) {
        Inventory inv = p.getInventory();
        List<ItemStack> saved = null;
        for (int slot : STORED) {
            ItemStack s = inv.getItem(slot);
            int si = skillIndexOfSlot(slot);
            boolean want = si != AEGIS_IDX || p.getAttachedOrElse(HAS_AEGIS, false);
            if (si >= 0 && want) {
                if (!s.is(SKILLS.get(si))) {
                    if (!s.isEmpty() && !isSkill(s)) saved = stash(p, saved, s);
                    inv.setItem(slot, new ItemStack(SKILLS.get(si)));
                }
            } else if (!s.isEmpty()) {
                if (!isSkill(s)) saved = stash(p, saved, s);
                inv.setItem(slot, ItemStack.EMPTY);
            }
        }
        if (saved != null) p.setAttached(SAVED, saved);
    }

    static List<ItemStack> stash(ServerPlayer p, List<ItemStack> saved, ItemStack s) {
        if (saved == null) saved = new ArrayList<>(p.getAttachedOrElse(SAVED, List.of()));
        for (int k = 0; k < STORED.length; k++) {
            if (k >= saved.size()) saved.add(ItemStack.EMPTY);
            if (saved.get(k).isEmpty()) { saved.set(k, s.copy()); return saved; }
        }
        p.drop(s.copy(), false);
        return saved;
    }

    // ---------------- Каст ----------------
    static void cast(ServerPlayer p, int idx) {
        if (CHANNELS.containsKey(p.getUUID())) return;
        ItemStack st = new ItemStack(SKILLS.get(idx));
        if (p.getCooldowns().isOnCooldown(st)) return;

        ServerLevel sl = (ServerLevel) p.level();
        long now = sl.getGameTime();
        switch (idx) {
            case 0 -> { // Лазер: 4 урона + "ослепление"
                LivingEntity t = beam(p, 30, false);
                if (t != null) {
                    t.hurtServer(sl, p.damageSources().playerAttack(p), 4f);
                    BLIND.put(t.getUUID(), new Blind(p.getUUID(), now + BLIND_TICKS));
                    t.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, BLIND_TICKS, 0, false, false));
                }
                sl.playSound(null, p.blockPosition(), SoundEvents.BEACON_POWER_SELECT, SoundSource.PLAYERS, 1f, 1.8f);
            }
            case 1 -> spawnMarches(p, sl, now);
            case 6 -> {
                msg(p, "Эгида: воскресишь себя через 3 c после смерти", true);
                return;
            }
            case 2 -> {
                DOME.put(p.getUUID(), now + 60);
                sl.playSound(null, p.blockPosition(), SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 1f, 1f);
            }
            case 3 -> { // Варп-флейр: стан 1 сек, дальность как у лазера
                LivingEntity t = beam(p, 30, true);
                if (t != null) {
                    t.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, 20, 255, false, true));
                    t.setDeltaMovement(0, Math.min(0, t.getDeltaMovement().y), 0);
                    t.hurtMarked = true;
                }
                sl.playSound(null, p.blockPosition(), SoundEvents.BEACON_POWER_SELECT, SoundSource.PLAYERS, 1f, 0.7f);
            }
            case 4 -> {
                CHANNELS.put(p.getUUID(), new Channel(4, now + REARM_TICKS));
                sl.playSound(null, p.blockPosition(), SoundEvents.BEACON_AMBIENT, SoundSource.PLAYERS, 1f, 1.5f);
                return;
            }
            case 5 -> {
                CHANNELS.put(p.getUUID(), new Channel(5, now + TP_TICKS));
                sl.playSound(null, p.blockPosition(), SoundEvents.BEACON_AMBIENT, SoundSource.PLAYERS, 1f, 0.8f);
                return;
            }
        }
        if (CD[idx] > 0) p.getCooldowns().addCooldown(st, CD[idx]);
    }

    static LivingEntity beam(ServerPlayer p, double range, boolean rings) {
        ServerLevel sl = (ServerLevel) p.level();
        Vec3 eye = p.getEyePosition(), dir = p.getLookAngle();
        Vec3 end = eye.add(dir.scale(range));
        BlockHitResult bh = sl.clip(new ClipContext(eye, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        double len = bh.getLocation().distanceTo(eye);
        Vec3 stop = eye.add(dir.scale(len));
        EntityHitResult eh = ProjectileUtil.getEntityHitResult(p, eye, stop,
                p.getBoundingBox().expandTowards(dir.scale(len)).inflate(1.0),
                e -> e instanceof LivingEntity && !(e instanceof ArmorStand) && !e.isSpectator() && e.isPickable(),
                len * len);
        LivingEntity target = null;
        if (eh != null) {
            target = (LivingEntity) eh.getEntity();
            len = eh.getLocation().distanceTo(eye);
        }
        ParticleOptions main = new DustParticleOptions(rings ? 0x33E6FF : 0xFF2020, 1f);
        Vec3 up = Math.abs(dir.y) > 0.99 ? new Vec3(1, 0, 0) : new Vec3(0, 1, 0);
        Vec3 u = dir.cross(up).normalize();
        Vec3 v = dir.cross(u).normalize();
        int i = 0;
        for (double t = 0.8; t < len; t += 0.4, i++) {
            Vec3 pt = eye.add(dir.scale(t)).add(0, -0.2, 0);
            sl.sendParticles(main, pt.x, pt.y, pt.z, 1, 0, 0, 0, 0);
            if (rings && i % 4 == 0) {
                for (int k = 0; k < 12; k++) {
                    double a = k * Math.PI * 2 / 12;
                    Vec3 o = u.scale(Math.cos(a) * 0.6).add(v.scale(Math.sin(a) * 0.6));
                    sl.sendParticles(ParticleTypes.END_ROD, pt.x + o.x, pt.y + o.y, pt.z + o.z, 1, 0, 0, 0, 0);
                }
            }
        }
        if (rings) { // шарик на конце луча
            Vec3 e = eye.add(dir.scale(len));
            sl.sendParticles(ParticleTypes.END_ROD, e.x, e.y, e.z, 12, 0.2, 0.2, 0.2, 0.02);
        }
        return target;
    }

    // ---------------- Марши ----------------
    static void spawnMarches(ServerPlayer p, ServerLevel sl, long now) {
        Vec3 look = p.getLookAngle();
        Vec3 fwd = new Vec3(look.x, 0, look.z);
        fwd = fwd.lengthSqr() < 1e-4 ? new Vec3(0, 0, 1) : fwd.normalize();
        Vec3 right = new Vec3(-fwd.z, 0, fwd.x);
        Vec3 origin = p.position();
        float yaw = (float) Math.toDegrees(Math.atan2(-fwd.x, fwd.z));
        for (int i = 0; i < 12; i++) {
            double lat = -2.75 + i * 0.5;
            Vec3 start = origin.add(fwd.scale(-3 - Math.random() * 0.6)).add(right.scale(lat));
            ArmorStand st = new ArmorStand(sl, start.x, start.y, start.z);
            makeSmall(st);
            st.setInvulnerable(true);
            st.setSilent(true);
            st.setNoGravity(true);
            st.setYRot(yaw);
            st.setItemSlot(EquipmentSlot.HEAD, new ItemStack(Items.IRON_BLOCK));
            sl.addFreshEntity(st);
            ROBOTS.add(new Robot(st, p.getUUID(), start, fwd, now));
        }
        sl.playSound(null, p.blockPosition(), SoundEvents.IRON_GOLEM_REPAIR, SoundSource.PLAYERS, 1f, 1.5f);
    }

    // ---------------- Тики ----------------
    void serverTick(MinecraftServer server) {
        for (ServerPlayer p : server.getPlayerList().getPlayers()) playerTick(p);
        if (DotaMap.current != null && DotaMap.current.tick()) DotaMap.current = null;
        tickRobots(server);
    }

    void playerTick(ServerPlayer p) {
        ServerLevel sl = (ServerLevel) p.level();
        long now = sl.getGameTime();
        UUID id = p.getUUID();

        scanAegis(p);
        tickRevive(p, sl, now);
        if (p.getAttachedOrElse(MODE, false)) enforce(p);

        Long dome = DOME.get(id);
        if (dome != null) {
            if (dome <= now) DOME.remove(id);
            else {
                ParticleOptions c = new DustParticleOptions(0x4D99FF, 1f);
                for (int i = 0; i < 25; i++) {
                    double th = Math.random() * Math.PI * 2, ph = Math.acos(2 * Math.random() - 1);
                    sl.sendParticles(c, p.getX() + 2.2 * Math.sin(ph) * Math.cos(th),
                            p.getY() + 1 + 2.2 * Math.cos(ph),
                            p.getZ() + 2.2 * Math.sin(ph) * Math.sin(th), 1, 0, 0, 0, 0);
                }
            }
        }

        Channel ch = CHANNELS.get(id);
        if (ch != null) {
            // несколько колец вокруг игрока
            ParticleOptions col = new DustParticleOptions(ch.type() == 5 ? 0x33E6FF : 0xB266FF, 1f);
            int rings = 3;
            for (int k = 0; k < rings; k++) {
                double y = p.getY() + ((now * 0.05 + k * 0.7) % 2.1);
                for (int j = 0; j < 14; j++) {
                    double a = j * Math.PI * 2 / 14 + now * 0.25 * (k % 2 == 0 ? 1 : -1);
                    sl.sendParticles(col, p.getX() + Math.cos(a), y, p.getZ() + Math.sin(a), 1, 0, 0, 0, 0);
                }
            }
            if (now >= ch.end()) {
                CHANNELS.remove(id);
                if (ch.type() == 4) { // Реарм: сброс всех КД, включая свой
                    var cd = p.getCooldowns();
                    for (Item it : SKILLS) {
                        ItemStack s = new ItemStack(it);
                        cd.removeCooldown(cd.getCooldownGroup(s));
                    }
                    msg(p, "Реарм: все способности сброшены!", true);
                    sl.playSound(null, p.blockPosition(), SoundEvents.PLAYER_LEVELUP, SoundSource.PLAYERS, 1f, 1f);
                } else {              // ТП: к точке спавна
                    teleportHome(p);
                    p.getCooldowns().addCooldown(new ItemStack(SKILLS.get(5)), CD[5]);
                }
            }
        }
    }

    static void teleportHome(ServerPlayer p) {
        MinecraftServer srv = p.level().getServer();
        ServerLevel target;
        BlockPos pos;
        var cfg = p.getRespawnConfig();
        if (cfg != null) {
            target = srv.getLevel(cfg.respawnData().dimension());
            pos = cfg.respawnData().pos();
        } else {
            target = srv.overworld();
            pos = target.getRespawnData().pos();
        }
        if (target == null) return;
        ((ServerLevel) p.level()).sendParticles(ParticleTypes.PORTAL, p.getX(), p.getY() + 1, p.getZ(), 40, 0.5, 1, 0.5, 0.3);
        p.teleportTo(target, pos.getX() + 0.5, pos.getY() + 0.6, pos.getZ() + 0.5, Set.of(), p.getYRot(), p.getXRot(), true);
    }

    void tickRobots(MinecraftServer server) {
        if (ROBOTS.isEmpty()) return;
        Iterator<Robot> it = ROBOTS.iterator();
        while (it.hasNext()) {
            Robot r = it.next();
            ArmorStand st = r.stand();
            if (st.isRemoved()) { it.remove(); continue; }
            ServerLevel sl = (ServerLevel) st.level();
            long t = sl.getGameTime() - r.born();
            if (t > MARCH_LIFETIME) { st.discard(); it.remove(); continue; }

            // идут по прямой: от -3 блоков за тобой до +5 впереди (точка каста), на месте мира, за тобой не едут
            double travel = 8.0 * t / MARCH_LIFETIME;
            Vec3 pos = r.start().add(r.fwd().scale(travel));
            BlockPos bp = BlockPos.containing(pos.x, st.getY(), pos.z);
            double y = st.getY();
            if (!sl.getBlockState(bp).getCollisionShape(sl, bp).isEmpty()) y = bp.getY() + 1;
            else if (sl.getBlockState(bp.below()).getCollisionShape(sl, bp.below()).isEmpty()) y -= 0.5;
            st.setPos(pos.x, y, pos.z);

            List<LivingEntity> hit = sl.getEntitiesOfClass(LivingEntity.class,
                    st.getBoundingBox().inflate(0.25, 0.3, 0.25), x -> !(x instanceof ArmorStand));
            if (hit.isEmpty()) continue;

            LivingEntity who = hit.get(0);
            ServerPlayer owner = server.getPlayerList().getPlayer(r.owner());
            if (who.getUUID().equals(r.owner())) {
                who.heal(0.5f);
            } else {
                DamageSource src = owner != null ? sl.damageSources().playerAttack(owner) : sl.damageSources().magic();
                who.hurtServer(sl, src, 0.5f);
            }
            sl.sendParticles(ParticleTypes.CRIT, st.getX(), st.getY() + 0.3, st.getZ(), 6, 0.2, 0.2, 0.2, 0.1);
            st.discard();
            it.remove();
        }
    }
}
