Dota2 Minecraft (Fabric 26.1.2, Java 25, нужен Fabric API)
Сборка jar: загрузи этот zip в репозиторий GitHub, Actions соберёт Dota2-Minecraft-<версия>.jar (Artifacts).
В игре: /give @s minecraft:tinker_book -> ПКМ книгой -> G. Карта: /dotamap. Вкладка: Dota2 Characters.
