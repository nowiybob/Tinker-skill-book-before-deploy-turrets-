Готовый jar собирается автоматически через GitHub Actions (на телефоне ничего ставить не надо):
1) Создай репозиторий на github.com и загрузи в него ВСЮ эту папку (включая .github, src, build.gradle...).
2) Вкладка Actions -> "Build mod jar" -> Run workflow (или просто после загрузки запустится сама).
3) Когда станет зелёной - открой запуск, внизу Artifacts -> skillbook-jar -> скачай, внутри skillbook-2.0.0.jar.
4) Положи jar (не -sources) в папку mods вместе с Fabric API. Minecraft 26.1.2, Fabric Loader, Java 25.
Если сборка красная - пришли мне текст ошибки из лога.
В игре: /give @s minecraft:tinker_book -> ПКМ книгой -> G.
