package com.example.skillbook;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSystemChatPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LeavesBlock;
import net.minecraft.world.level.block.state.BlockState;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Упрощённая карта в стиле Dota 2 (500x500 блоков). Radiant - левый нижний угол, Dire - правый верхний.
 * Три линии, река по диагонали, 2 логова Рошана, башни, базы, лагеря, лес.
 * Строится порциями по одному куску за тик, чтобы не вешать сервер.
 */
final class DotaMap {
    static DotaMap current = null;

    static final int SIZE = 500, HALF = 250, TILE = 16, TILES_PER_SIDE = 32;
    static final int LANE = 1, RIVER = 2, JUNGLE = 0;

    static final BlockState AIR = Blocks.AIR.defaultBlockState();
    static final BlockState WATER = Blocks.WATER.defaultBlockState();
    static final BlockState SAND = Blocks.SAND.defaultBlockState();
    static final BlockState DIRT = Blocks.DIRT.defaultBlockState();

    // линии: {x1, z1, x2, z2} относительно центра карты
    static final double[][] LANES = {
            {-190, 190, 190, -190},     // мид
            {-200, 190, -200, -200},    // верх: левый край
            {-200, -200, 190, -200},    // верх: верхний край
            {-190, 200, 200, 200},      // низ: нижний край
            {200, 200, 200, -190}       // низ: правый край
    };
    // башни Radiant (для Dire зеркально)
    static final int[][] TOWERS = {
            {-65, 65}, {-110, 110}, {-150, 150},          // мид T1-T3
            {-200, -110}, {-200, 30}, {-200, 140},        // верх T1-T3
            {110, 200}, {-30, 200}, {-140, 200},          // низ T1-T3
            {-175, 185}, {-185, 175}                      // T4 у трона
    };
    // лагеря Radiant (для Dire зеркально)
    static final int[][] CAMPS = {
            {-150, 40}, {-160, -40}, {-100, -30}, {-60, 10},
            {-60, 150}, {10, 170}, {-100, 170}, {40, 110}
    };
    // казармы Radiant
    static final int[][] RAX = {{-185, 150}, {-143, 157}, {-150, 185}};

    final ServerLevel level;
    final UUID owner;
    final int cx, cz, by;
    int phase = 0, tile = 0, structIdx = 0, lastPercent = -1;
    final List<Runnable> structures = new ArrayList<>();
    final BlockPos.MutableBlockPos mp = new BlockPos.MutableBlockPos();
    boolean cancelled = false;

    DotaMap(ServerLevel level, UUID owner, int cx, int by, int cz) {
        this.level = level; this.owner = owner; this.cx = cx; this.by = by; this.cz = cz;
    }

    // ---------- Тики ----------
    /** @return true когда закончили */
    boolean tick() {
        if (cancelled) return true;
        switch (phase) {
            case 0 -> {
                doTile(tile, false);
                if (++tile >= TILES_PER_SIDE * TILES_PER_SIDE) { tile = 0; phase = 1; }
                progress(tile * 100 / (TILES_PER_SIDE * TILES_PER_SIDE) / 2);
            }
            case 1 -> {
                doTile(tile, true);
                if (++tile >= TILES_PER_SIDE * TILES_PER_SIDE) { phase = 2; buildStructures(); }
                progress(50 + tile * 100 / (TILES_PER_SIDE * TILES_PER_SIDE) / 3);
            }
            case 2 -> {
                for (int i = 0; i < 25 && structIdx < structures.size(); i++) structures.get(structIdx++).run();
                progress(83 + structIdx * 17 / Math.max(1, structures.size()));
                if (structIdx >= structures.size()) { finish(); return true; }
            }
        }
        return false;
    }

    void progress(int pct) {
        if (pct / 5 == lastPercent) return;
        lastPercent = pct / 5;
        say("Карта: " + pct + "%", true);
    }

    void say(String text, boolean overlay) {
        ServerPlayer p = level.getServer().getPlayerList().getPlayer(owner);
        if (p != null) p.connection.send(new ClientboundSystemChatPacket(Component.literal(text), overlay));
    }

    void finish() {
        // Эгида лежит в сундуке на постаменте в логове Рошана (верхнее логово).
        // Сундук надёжнее выброшенного предмета: он сохраняется вместе с миром.
        int px = cx + PIT_A[0], pz = cz + PIT_A[1];
        set(px, by - 3, pz, Blocks.GOLD_BLOCK.defaultBlockState());
        set(px, by - 2, pz, Blocks.CHEST.defaultBlockState());
        if (level.getBlockEntity(mp.set(px, by - 2, pz)) instanceof net.minecraft.world.Container c) {
            c.setItem(13, new ItemStack(SkillBookMod.AEGIS));
        }
        say("Карта готова! Эгида в сундуке в логове Рошана (" + px + ", " + pz + "). Radiant: юго-запад, Dire: северо-восток.", false);
    }

    // ---------- Зоны ----------
    static double segDist(double px, double pz, double ax, double az, double bx, double bz) {
        double dx = bx - ax, dz = bz - az;
        double t = ((px - ax) * dx + (pz - az) * dz) / (dx * dx + dz * dz);
        t = Math.max(0, Math.min(1, t));
        return Math.hypot(px - (ax + t * dx), pz - (az + t * dz));
    }

    static int zone(int rx, int rz) {
        for (double[] l : LANES) if (segDist(rx, rz, l[0], l[1], l[2], l[3]) <= 5) return LANE;
        int off = (int) Math.round(8 * Math.sin((rx + rz) * 0.04));
        if (Math.abs(rx - rz - off) <= 9) return RIVER;
        return JUNGLE;
    }

    static boolean radiantSide(int rx, int rz) { return rx - rz < 0; }

    // ---------- Рельеф и деревья ----------
    void set(int x, int y, int z, BlockState s) { level.setBlock(mp.set(x, y, z), s, 2); }

    boolean isAir(int x, int y, int z) { return level.getBlockState(mp.set(x, y, z)).isAir(); }

    void fill(int x1, int y1, int z1, int x2, int y2, int z2, BlockState s) {
        for (int x = Math.min(x1, x2); x <= Math.max(x1, x2); x++)
            for (int y = Math.min(y1, y2); y <= Math.max(y1, y2); y++)
                for (int z = Math.min(z1, z2); z <= Math.max(z1, z2); z++) set(x, y, z, s);
    }

    static int hash(int x, int z) {
        int h = (x * 73856093) ^ (z * 19349663);
        h ^= h >>> 13; h *= 0x5bd1e995; h ^= h >>> 15;
        return h & 0x7fffffff;
    }

    void doTile(int idx, boolean trees) {
        int tx = idx % TILES_PER_SIDE, tz = idx / TILES_PER_SIDE;
        int minX = cx - HALF + tx * TILE, minZ = cz - HALF + tz * TILE;
        int maxX = Math.min(minX + TILE, cx + HALF), maxZ = Math.min(minZ + TILE, cz + HALF);
        for (int x = minX; x < maxX; x++) {
            for (int z = minZ; z < maxZ; z++) {
                int rx = x - cx, rz = z - cz;
                int zn = zone(rx, rz);
                if (!trees) {
                    for (int dy = 1; dy <= 32; dy++) if (!isAir(x, by + dy, z)) set(x, by + dy, z, AIR);
                    if (zn == RIVER) {
                        set(x, by, z, AIR);
                        set(x, by - 1, z, WATER);
                        set(x, by - 2, z, SAND);
                        set(x, by - 3, z, SAND);
                        set(x, by - 4, z, DIRT);
                    } else {
                        BlockState top = zn == LANE ? Blocks.DIRT_PATH.defaultBlockState()
                                : radiantSide(rx, rz) ? Blocks.GRASS_BLOCK.defaultBlockState() : Blocks.PODZOL.defaultBlockState();
                        set(x, by, z, top);
                        set(x, by - 1, z, DIRT);
                        set(x, by - 2, z, DIRT);
                        set(x, by - 3, z, DIRT);
                    }
                } else if (zn == JUNGLE && hash(x, z) % 90 == 0
                        && Math.max(Math.abs(rx + 190), Math.abs(rz - 190)) > 40
                        && Math.max(Math.abs(rx - 190), Math.abs(rz + 190)) > 40) {
                    tree(x, z, radiantSide(rx, rz), 5 + hash(z, x) % 3);
                }
            }
        }
    }

    void tree(int x, int z, boolean radiant, int h) {
        BlockState log = (radiant ? Blocks.OAK_LOG : Blocks.DARK_OAK_LOG).defaultBlockState();
        BlockState leaves = (radiant ? Blocks.OAK_LEAVES : Blocks.DARK_OAK_LEAVES).defaultBlockState()
                .setValue(LeavesBlock.PERSISTENT, true);
        for (int y = 1; y <= h; y++) set(x, by + y, z, log);
        for (int dy = h - 2; dy <= h + 1; dy++) {
            int r = dy >= h ? 1 : 2;
            for (int dx = -r; dx <= r; dx++)
                for (int dz = -r; dz <= r; dz++) {
                    if (Math.abs(dx) == r && Math.abs(dz) == r && dy >= h - 1) continue;
                    if (dx == 0 && dz == 0 && dy <= h) continue;
                    if (isAir(x + dx, by + dy, z + dz)) set(x + dx, by + dy, z + dz, leaves);
                }
        }
    }

    // ---------- Постройки ----------
    static final int[] PIT_A = {-95, -105}, PIT_B = {95, 105};

    void buildStructures() {
        for (int s : new int[]{1, -1}) {
            final int sg = s;
            structures.add(() -> base(sg));
            for (int[] t : TOWERS) structures.add(() -> tower(cx + sg * t[0], cz + sg * t[1], sg == 1));
            for (int[] c : CAMPS) structures.add(() -> camp(cx + sg * c[0], cz + sg * c[1]));
            for (int[] r : RAX) structures.add(() -> barracks(cx + sg * r[0], cz + sg * r[1], sg == 1));
        }
        structures.add(() -> pit(cx + PIT_A[0], cz + PIT_A[1]));
        structures.add(() -> pit(cx + PIT_B[0], cz + PIT_B[1]));
    }

    void base(int s) {
        boolean rad = s == 1;
        int x = cx + s * -190, z = cz + s * 190;
        BlockState floor = (rad ? Blocks.STONE_BRICKS : Blocks.POLISHED_BLACKSTONE_BRICKS).defaultBlockState();
        BlockState wall = (rad ? Blocks.QUARTZ_BLOCK : Blocks.NETHER_BRICKS).defaultBlockState();
        BlockState wall2 = (rad ? Blocks.SMOOTH_QUARTZ : Blocks.RED_NETHER_BRICKS).defaultBlockState();
        BlockState light = (rad ? Blocks.SEA_LANTERN : Blocks.SHROOMLIGHT).defaultBlockState();
        fill(x - 14, by, z - 14, x + 14, by, z + 14, floor);          // площадь базы
        fill(x - 4, by + 1, z - 4, x + 4, by + 1, z + 4, wall2);      // постамент
        fill(x - 2, by + 2, z - 2, x + 2, by + 5, z + 2, wall);       // трон (низ)
        fill(x - 1, by + 6, z - 1, x + 1, by + 9, z + 1, wall2);      // трон (верх)
        set(x, by + 10, z, light);
        // фонтан в углу базы
        int fx = x + s * -10, fz = z + s * 10;
        fill(fx - 2, by + 1, fz - 2, fx + 2, by + 1, fz + 2, floor);
        fill(fx - 1, by + 1, fz - 1, fx + 1, by + 1, fz + 1, WATER);
        // фонари по углам площади
        for (int dx : new int[]{-14, 14}) for (int dz : new int[]{-14, 14}) {
            fill(x + dx, by + 1, z + dz, x + dx, by + 3, z + dz, wall);
            set(x + dx, by + 4, z + dz, light);
        }
    }

    void tower(int x, int z, boolean rad) {
        BlockState base = (rad ? Blocks.STONE_BRICKS : Blocks.POLISHED_BLACKSTONE_BRICKS).defaultBlockState();
        BlockState shaft = (rad ? Blocks.QUARTZ_PILLAR : Blocks.NETHER_BRICKS).defaultBlockState();
        BlockState top = (rad ? Blocks.QUARTZ_BLOCK : Blocks.RED_NETHER_BRICKS).defaultBlockState();
        BlockState light = (rad ? Blocks.SEA_LANTERN : Blocks.SHROOMLIGHT).defaultBlockState();
        fill(x - 1, by + 1, z - 1, x + 1, by + 2, z + 1, base);
        fill(x, by + 3, z, x, by + 9, z, shaft);
        fill(x - 1, by + 10, z - 1, x + 1, by + 10, z + 1, top);
        set(x, by + 11, z, light);
    }

    void camp(int x, int z) {
        BlockState coarse = Blocks.COARSE_DIRT.defaultBlockState();
        for (int dx = -3; dx <= 3; dx++)
            for (int dz = -3; dz <= 3; dz++)
                if (dx * dx + dz * dz <= 10) set(x + dx, by, z + dz, coarse);
        set(x, by + 1, z, Blocks.HAY_BLOCK.defaultBlockState());
        set(x + 2, by + 1, z + 2, Blocks.CAMPFIRE.defaultBlockState());
    }

    void barracks(int x, int z, boolean rad) {
        BlockState wall = (rad ? Blocks.STONE_BRICKS : Blocks.NETHER_BRICKS).defaultBlockState();
        BlockState roof = (rad ? Blocks.QUARTZ_BLOCK : Blocks.RED_NETHER_BRICKS).defaultBlockState();
        BlockState light = (rad ? Blocks.SEA_LANTERN : Blocks.SHROOMLIGHT).defaultBlockState();
        fill(x - 3, by + 1, z - 3, x + 3, by + 4, z + 3, wall);
        fill(x - 3, by + 5, z - 3, x + 3, by + 5, z + 3, roof);
        set(x, by + 6, z, light);
    }

    /** Логово Рошана: яма 13x13, рампа с востока. */
    void pit(int x, int z) {
        int floor = by - 4;
        BlockState shell = Blocks.DEEPSLATE_BRICKS.defaultBlockState();
        fill(x - 7, floor - 1, z - 7, x + 7, by + 1, z + 7, shell);          // стены (вода реки не затопит)
        fill(x - 5, floor, z - 5, x + 5, by + 8, z + 5, AIR);                // внутренность
        fill(x - 5, floor, z - 5, x + 5, floor, z + 5, Blocks.STONE_BRICKS.defaultBlockState());
        for (int dx : new int[]{-4, 4}) for (int dz : new int[]{-4, 4})
            set(x + dx, floor, z + dz, Blocks.SEA_LANTERN.defaultBlockState());
        // рампа вверх на восток (ступени по 1 блоку)
        for (int k = 1; k <= 4; k++) {
            int xx = x + 5 + k, fy = floor + k;
            for (int dz = -1; dz <= 1; dz++) {
                fill(xx, fy + 1, z + dz, xx, by + 6, z + dz, AIR);
                set(xx, fy, z + dz, Blocks.STONE_BRICKS.defaultBlockState());
            }
        }
    }
}
