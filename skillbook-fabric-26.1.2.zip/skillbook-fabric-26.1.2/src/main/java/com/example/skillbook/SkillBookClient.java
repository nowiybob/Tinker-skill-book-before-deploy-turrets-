package com.example.skillbook;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;

public class SkillBookClient implements ClientModInitializer {
    static KeyMapping KEY;

    @Override
    public void onInitializeClient() {
        // Клавиша видна в Настройки -> Управление -> "Skill Book", её можно перебиндить
        KeyMapping.Category cat = KeyMapping.Category.register(
                Identifier.fromNamespaceAndPath(SkillBookMod.MODID, "main"));
        KEY = KeyMappingHelper.registerKeyMapping(
                new KeyMapping("key.skillbook.toggle", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_G, cat));

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (KEY.consumeClick()) {
                if (mc.player != null) mc.player.connection.sendCommand("skillmode");
            }
        });
    }
}
